var searchData=
[
  ['generalspin_5fs_554',['GeneralSpin_S',['../namespacemrock_1_1symbolic__operators.html#a00b4de95ca3614d05a4cd510f1e27d10a8dcb19ecbc89a7f5644dcaf4ab45fcf0',1,'mrock::symbolic_operators']]],
  ['generalspin_5fsprime_555',['GeneralSpin_SPrime',['../namespacemrock_1_1symbolic__operators.html#a00b4de95ca3614d05a4cd510f1e27d10a84760386623dda79a1235d58be290e46',1,'mrock::symbolic_operators']]]
];
