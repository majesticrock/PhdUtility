var searchData=
[
  ['momentum_5fsymbols_547',['momentum_symbols',['../namespacemrock_1_1symbolic__operators.html#a1c5de41b3cc5eb1e501b0028315ce6fa',1,'mrock::symbolic_operators']]],
  ['momentumsum_548',['MomentumSum',['../namespacemrock_1_1symbolic__operators.html#a10f0251a0a2fcd4b4369776121e863d7',1,'mrock::symbolic_operators']]]
];
