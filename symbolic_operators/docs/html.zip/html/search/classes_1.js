var searchData=
[
  ['coefficient_283',['Coefficient',['../structmrock_1_1symbolic__operators_1_1Coefficient.html',1,'mrock::symbolic_operators']]]
];
