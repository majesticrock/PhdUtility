var searchData=
[
  ['q_5fchanges_5fsign_193',['Q_changes_sign',['../structmrock_1_1symbolic__operators_1_1Coefficient.html#afde45176ea480e61fd4f4f11dc4de81d',1,'mrock::symbolic_operators::Coefficient']]]
];
