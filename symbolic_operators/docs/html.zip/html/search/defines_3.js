var searchData=
[
  ['if_5fis_5fterm_5ftracked_576',['IF_IS_TERM_TRACKED',['../Term_8hpp.html#a6d27afb2ab7359c4517ad6c102704e96',1,'Term.hpp']]]
];
